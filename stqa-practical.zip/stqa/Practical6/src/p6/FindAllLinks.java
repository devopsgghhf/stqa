package p6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;

public class FindAllLinks {
    static String driverPath = "C:\\Users\\Asus\\Downloads\\geckodriver-v0.35.0-win64\\geckodriver.exe";

    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", driverPath);

        // Launch Firefox
        WebDriver driver = new FirefoxDriver();

        // Open Google
        String appUrl = "https://www.google.co.in/";
        driver.get(appUrl);

        // Find all links on the page
        List<WebElement> links = driver.findElements(By.tagName("a"));

        // Print link text
        for (int i = 0; i < links.size(); i++) {
            System.out.println(links.get(i).getText());
        }

        // Print total number of links
        System.out.println("Total No. of Links: " + links.size());

        // Close browser
        driver.quit();
    }
}
