package p4;

import jxl.*; // WorkbookSettings, Workbook
import jxl.write.*; // WriteException, WritableWorkbook, WritableSheet, Label
import jxl.write.Number; // Number for numeric cells
import java.io.*; // IOException, File
import java.util.Locale; // Locale

public class Stud_Data {

    public static void main(String[] args) throws IOException, WriteException {
        int r = 0, c = 0;

        String header[] = {"Student Name", "Subject1", "Subject2", "Subject3", "Total"};

        String sname[] = {"Carls", "James", "Paul", "Philip", "Smith", "Thomson", 
                          "Rhodey", "Stark", "Gary", "AnneMarie"};

        // Each student has 3 subject marks
        int marks[] = {
            50, 45, 60,   // Carls
            55, 70, 45,   // James
            67, 78, 89,   // Paul
            90, 30, 56,   // Philip
            65, 72, 81,   // Smith
            49, 53, 60,   // Thomson
            77, 69, 82,   // Rhodey
            91, 87, 79,   // Stark
            62, 74, 68,   // Gary
            88, 92, 85    // AnneMarie
        };

        File file = new File("student.xls");
        WorkbookSettings wbSettings = new WorkbookSettings();
        wbSettings.setLocale(new Locale("en", "EN"));
        WritableWorkbook workbook = Workbook.createWorkbook(file, wbSettings);
        workbook.createSheet("Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);

        // creating header row
        for (c = 0; c < header.length; c++) {
            Label l = new Label(c, 0, header[c]);
            excelSheet.addCell(l);
        }

        // filling names in column 1
        for (r = 1; r <= sname.length; r++) {
            Label l = new Label(0, r, sname[r - 1]);
            excelSheet.addCell(l);
        }

        // filling subjects marks (columns 2,3,4)
        for (r = 1; r <= sname.length; r++) {
            int baseIndex = (r - 1) * 3; // index in marks array
            for (c = 1; c <= 3; c++) {
                Number num = new Number(c, r, marks[baseIndex + (c - 1)]);
                excelSheet.addCell(num);
            }
        }

        // filling totals in column 5
        for (r = 1; r <= sname.length; r++) {
            int baseIndex = (r - 1) * 3;
            int total = marks[baseIndex] + marks[baseIndex + 1] + marks[baseIndex + 2];
            Number num = new Number(4, r, total);
            excelSheet.addCell(num);
        }

        workbook.write();
        workbook.close();
        System.out.println("Excel File Created!!!!!");
    }
}
