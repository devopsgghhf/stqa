package p8;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CheckBox {
    static String driverPath = "C:\\Users\\Asus\\Downloads\\geckodriver-v0.35.0-win64\\geckodriver.exe";

    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", driverPath);

        // Launch Firefox
        WebDriver driver = new FirefoxDriver();

        // Use either a live website OR local file
         String appUrl = "https://practice.expandtesting.com/checkboxes"; // dynamic test site
       // String appUrl = "C:\\Users\\Asus\\Downloads\\stqa\\CheckBox.html"; // local file

        // Open the page
        driver.get(appUrl);

        // Find all checkboxes
        List<WebElement> checkBoxes = driver.findElements(By.xpath("//input[@type='checkbox']"));

        int checkedCount = 0, uncheckedCount = 0;

        for (int i = 0; i < checkBoxes.size(); i++) {
            System.out.println("Checkbox " + (i + 1) + " is selected: " + checkBoxes.get(i).isSelected());

            if (checkBoxes.get(i).isSelected()) {
                checkedCount++;
            } else {
                uncheckedCount++;
            }
        }

        // Print summary
        System.out.println("No. of selected checkboxes: " + checkedCount);
        System.out.println("No. of unselected checkboxes: " + uncheckedCount);

        // Close browser
        driver.quit();
    }
}
