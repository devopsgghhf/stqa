package p7;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class ComboBox {
    static String driverPath = "C:\\Users\\Asus\\Downloads\\geckodriver-v0.35.0-win64\\geckodriver.exe";

    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", driverPath);

        // Launch Firefox
        WebDriver driver = new FirefoxDriver();

        // Load local HTML file
        String appUrl = "C:\\Users\\Asus\\Downloads\\stqa\\Combobox.html";
        driver.get(appUrl);

        // Locate dropdown using id
        Select oSelect = new Select(driver.findElement(By.id("continents")));

        // Alternative locator (works too):
        // Select oSelect = new Select(driver.findElement(By.tagName("select")));

        // Get all options
        List<WebElement> oSize = oSelect.getOptions();
        int iListSize = oSize.size();

        // Print all options
        for (int i = 0; i < iListSize; i++) {
            String sValue = oSelect.getOptions().get(i).getText();
            System.out.println(sValue);
        }

        // Print total number of items
        System.out.println("Total No. of Items in Dropdown: " + iListSize);

        // Close browser
        driver.quit();
    }
}
